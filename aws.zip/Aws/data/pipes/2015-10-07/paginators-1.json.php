<?php
// This file was auto-generated from sdk-root/src/data/pipes/2015-10-07/paginators-1.json
return [ 'pagination' => [ 'ListPipes' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'Limit', 'result_key' => 'Pipes', ], ],];
