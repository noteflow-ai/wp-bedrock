<?php
// This file was auto-generated from sdk-root/src/data/states/2016-11-23/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListActivities', 'input' => [], 'errorExpectedFromService' => false, ], ],];
