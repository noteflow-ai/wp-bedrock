<?php
// This file was auto-generated from sdk-root/src/data/qapps/2023-11-27/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [],];
