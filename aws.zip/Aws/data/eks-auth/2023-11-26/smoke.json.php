<?php
// This file was auto-generated from sdk-root/src/data/eks-auth/2023-11-26/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [],];
