<?php
// This file was auto-generated from sdk-root/src/data/runtime.lex.v2/2020-08-07/paginators-1.json
return [ 'pagination' => [],];
