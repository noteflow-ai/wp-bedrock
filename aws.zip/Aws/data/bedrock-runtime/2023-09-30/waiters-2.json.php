<?php
// This file was auto-generated from sdk-root/src/data/bedrock-runtime/2023-09-30/waiters-2.json
return [ 'version' => 2, 'waiters' => [],];
