<?php
// This file was auto-generated from sdk-root/src/data/marketplace-reporting/2018-05-10/waiters-2.json
return [ 'version' => 2, 'waiters' => [],];
