<?php
// This file was auto-generated from sdk-root/src/data/payment-cryptography/2021-09-14/paginators-1.json
return [ 'pagination' => [ 'ListAliases' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Aliases', ], 'ListKeys' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Keys', ], 'ListTagsForResource' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', 'result_key' => 'Tags', ], ],];
