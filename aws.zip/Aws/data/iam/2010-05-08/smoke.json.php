<?php
// This file was auto-generated from sdk-root/src/data/iam/2010-05-08/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-east-1', 'testCases' => [ [ 'operationName' => 'ListUsers', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'GetUser', 'input' => [ 'UserName' => 'fake_user', ], 'errorExpectedFromService' => true, ], ],];
