<?php
// This file was auto-generated from sdk-root/src/data/pcs/2023-02-10/waiters-2.json
return [ 'version' => 2, 'waiters' => [],];
