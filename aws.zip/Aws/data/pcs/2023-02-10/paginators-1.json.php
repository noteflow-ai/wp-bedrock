<?php
// This file was auto-generated from sdk-root/src/data/pcs/2023-02-10/paginators-1.json
return [ 'pagination' => [ 'ListClusters' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'clusters', ], 'ListComputeNodeGroups' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'computeNodeGroups', ], 'ListQueues' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'queues', ], ],];
